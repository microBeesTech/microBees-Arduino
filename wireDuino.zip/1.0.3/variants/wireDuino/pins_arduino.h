#include "../standard/pins_arduino.h"
static const uint8_t HEADER_3 = A4;
static const uint8_t HEADER_5 = A5;
static const uint8_t HEADER_7 = A7;
static const uint8_t HEADER_8 = 4;
static const uint8_t HEADER_10= 3;
static const uint8_t HEADER_11 = A6;
static const uint8_t HEADER_12 = 9;
static const uint8_t HEADER_13 = 8;
static const uint8_t HEADER_15 = A2;
static const uint8_t HEADER_16 = A3;
static const uint8_t HEADER_19 = 11;
static const uint8_t HEADER_21 = 12;
static const uint8_t HEADER_22 = 2;
static const uint8_t HEADER_23 = 17;
static const uint8_t HEADER_26 = 10;
static const uint8_t BUTTON = 7;

