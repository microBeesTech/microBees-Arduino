#include "Arduino.h"
#ifndef MicroBees_h
#define MicroBees_h
#include <avr/wdt.h>
#define ADC_BITS    10
#define ADC_COUNTS  (1<<ADC_BITS)
class WireDuino
{
  public:
    WireDuino();
    void turnOnRelay();
    void turnOffRelay();
	void toggleRelay(uint8_t target_state);
	void loop();
	double realPower,
       apparentPower,
       powerFactor,
       Vrms,
       Irms;
	double realPowerAV=0,
       apparentPowerAV=0,
       powerFactorAV=0,
       VrmsAV=0,
       IrmsAV=0;
  private:
    double PHASECAL = 0;
	double VCAL = 533;
	double ICAL = 7.35;
	void powerMetering();
};
#endif