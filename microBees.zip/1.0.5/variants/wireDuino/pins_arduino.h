#include "../standard/pins_arduino.h"
#ifndef Pins_WireDuino
#define Pins_WireDuino
static const uint8_t HEADER_3 = 18;
static const uint8_t HEADER_5 = 19;
static const uint8_t HEADER_7 = 21;
static const uint8_t HEADER_8 = 4;
static const uint8_t HEADER_10= 3;
static const uint8_t HEADER_11 = 20;
static const uint8_t HEADER_12 = 9;
static const uint8_t HEADER_13 = 8;
static const uint8_t HEADER_15 = 16;
static const uint8_t HEADER_16 = 17;
static const uint8_t HEADER_19 = 11;
static const uint8_t HEADER_21 = 12;
static const uint8_t HEADER_22 = 2;
static const uint8_t HEADER_23 = 17;
static const uint8_t HEADER_26 = 10;
static const uint8_t BUTTON = 7;
static const uint8_t RELAY = 5;

#endif